<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$phone = sanitizeInput($_POST['phone'] ?? '');
$department = sanitizeInput($_POST['department'] ?? '');
$semester = intval($_POST['semester'] ?? 0);

if (empty($name) || empty($email) || empty($password) || empty($phone) || empty($department) || empty($semester)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all fields']);
    exit();
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit();
}

if (strlen($password) < 8) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters']);
    exit();
}

if ($password !== $confirm_password) {
    echo json_encode(['success' => false, 'message' => 'Passwords do not match']);
    exit();
}

if (!validatePhone($phone)) {
    echo json_encode(['success' => false, 'message' => 'Invalid phone number']);
    exit();
}

try {
    $checkStmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
    $checkStmt->execute([$email]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit();
    }
    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("
        INSERT INTO users (full_name, email, password, phone, department, semester) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([$name, $email, $hashedPassword, $phone, $department, $semester]);
    
    echo json_encode(['success' => true, 'message' => 'Registration successful! Please login.']);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
}
?>