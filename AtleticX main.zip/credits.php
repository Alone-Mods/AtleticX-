<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credits - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="credits-page">
        <div class="credits-container">
            <div class="credits-header">
                <h1>AtleticX Credits</h1>
                <p>College Project Team:</p>
            </div>
            
            <div class="credit-section">
                <h2>🏆 About AtleticX</h2>
                <div class="credit-content">
                    <p>AtleticX is a result of the teamwork of these individuals. This web application is used to manage the sports and games of your college</p>
                    <div class="project-stats">
                        <div class="stat">
                            <span class="stat-number">5</span>
                            <span class="stat-label">Sports Supported</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">1000+</span>
                            <span class="stat-label">Lines of Code</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">∞</span>
                            <span class="stat-label">Possibilities</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="credit-section">
                <h2>👨‍💻 Development Team</h2>
                    
                <div class="team-member">
                    <div class="member-avatar">AP</div>
                    <h3>Aswin Pramod</h3>
                    <p class="role">Frontend Developer</p>
                    <p class="contribution">Database Integration, API Development</p>
                </div>
                
                <div class="team-member">
                    <div class="member-avatar">MS</div>
                    <h3>Milan K Shiji</h3>
                    <p class="role">Frontend Developer</p>
                    <p class="contribution">UI Design, Responsive Layout</p>
                </div>
                
                <div class="team-member">
                    <div class="member-avatar">JP</div>
                    <h3>John Peter James</h3>
                    <p class="role">Designs</p>
                    <p class="contribution">Feature Implementation, Testing</p>
                </div>
                
                <div class="team-member">
                    <div class="member-avatar">MK</div>
                    <h3>Mathews K Sibi</h3>
                    <p class="role">Backend Developer</p>
                    <p class="contribution">Security Implementation, Database Design</p>
                </div>
                
                <div class="team-member">
                    <div class="member-avatar">NH</div>
                    <h3>Nehal</h3>
                    <p class="role">Frontend Developer</p>
                    <p class="contribution">Core supporter of the team😭💝</p>
                </div>
            </div>
            
            <div class="credit-section">
                <h2>🛠️ Technologies Used</h2>
                <div class="tech-grid">
                    <div class="tech-item">
                        <span class="tech-icon">🐘</span>
                        <h4>PHP</h4>
                        <p>Backend Development</p>
                    </div>
                    <div class="tech-item">
                        <span class="tech-icon">🗄️</span>
                        <h4>MySQL</h4>
                        <p>Database Management</p>
                    </div>
                    <div class="tech-item">
                        <span class="tech-icon">🎨</span>
                        <h4>HTML & CSS</h4>
                        <p>Frontend Structure & Styling</p>
                    </div>
                    <div class="tech-item">
                        <span class="tech-icon">⚡</span>
                        <h4>JavaScript</h4>
                        <p>Interactive Features</p>
                    </div>
                    <div class="tech-item">
                        <span class="tech-icon">🌐</span>
                        <h4>Apache</h4>
                        <p>Web Server</p>
                    </div>
                    <div class="tech-item">
                        <span class="tech-icon">🔒</span>
                        <h4>PDO by AI</h4>
                        <p>Secure Database Access</p>
                    </div>
                </div>
            </div>
            
            <div class="credit-section">
                <h2>📄 License & Usage</h2>
                <div class="license-content">
                    <p>This project is developed for educational purposes and is available under the MIT License. Feel free to use, modify, and distribute this project while providing appropriate credit.</p>
                    <div class="license-box">
                        <h4>MIT License</h4>
                        <p>Copyright (c) 2024 AtleticX Team</p>
                        <p>Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files, to deal in the Software without restriction.</p>
                    </div>
                </div>
            </div>
            
            <div class="credits-footer">
                <p>Made with ❤️ for UCE THODUPUZHA</p>
                <p>Version 1.0 | Released 2025</p>
                <a href="https://github.com/Alone-Mods/AtleticX" target="_blank" class="github-link">
                    View on GitHub
                </a>
            </div>
        </div>
    </main>
</body>
</html>