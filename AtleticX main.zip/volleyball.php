<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

$sport_id = 4;
$user_id = $_SESSION['user_id'];

$enrollCheck = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? AND sport_id = ?");
$enrollCheck->execute([$user_id, $sport_id]);
$isEnrolled = $enrollCheck->rowCount() > 0;

$sportStmt = $pdo->prepare("SELECT * FROM sports WHERE sport_id = ?");
$sportStmt->execute([$sport_id]);
$sport = $sportStmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volleyball - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="sport-detail-page">
        <div class="sport-hero volleyball-hero">
            <div class="hero-content">
                <span class="sport-icon-large">🏐</span>
                <h1>Volleyball</h1>
            </div>
        </div>
        
        <div class="sport-detail-container">
            <div class="sport-info-section">
                <p class="sport-description"><?php echo htmlspecialchars($sport['description'] ?? 'Spike your way to victory with our Volleyball team.'); ?></p>
                
                <div class="sport-stats">
                    <div class="stat-box">
                        <h3><?php echo $sport['current_members']; ?></h3>
                        <p>Active Members</p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo $sport['max_capacity'] - $sport['current_members']; ?></h3>
                        <p>Spots Available</p>
                    </div>
                </div>
                
                <div class="sport-actions-section">
                    <?php if (!$isEnrolled): ?>
                        <button class="btn-register" onclick="enrollInSport()">
                            <span class="btn-icon">✓</span>
                            Join Volleyball
                        </button>
                    <?php else: ?>
                        <button class="btn-enrolled" disabled>
                            <span class="btn-icon">✓</span>
                            Already Enrolled
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn-view-members" onclick="loadMembers()">
                        <span class="btn-icon">👥</span>
                        View Members
                    </button>
                </div>
            </div>
                        <div id="membersSection" class="members-section" style="display: none;">
                <h2>Team Members</h2>
                <div class="members-grid" id="membersGrid"></div>
            </div>
        </div>
    </main>
    
    <script>const SPORT_ID = <?php echo $sport_id; ?>;</script>
    <script src="assets/js/sport-functions.js"></script>
</body>
</html>