let membersVisible = false;

// Direct enrollment without modal
async function enrollInSport() {
    if (!confirm('Are you sure you want to join this sport?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'enroll');
    formData.append('sport_id', SPORT_ID);
    
    try {
        const response = await fetch('api/enrollment.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showAlert(data.message, 'error');
        }
    } catch (error) {
        showAlert('An error occurred. Please try again.', 'error');
    }
}

// Load and display team members
async function loadMembers() {
    const membersSection = document.getElementById('membersSection');
    const btn = document.querySelector('.btn-view-members');
    const membersGrid = document.getElementById('membersGrid');
    
    if (!membersVisible) {
        membersGrid.innerHTML = '<p style="text-align: center; width: 100%;">Loading members...</p>';
        membersSection.style.display = 'block';
        
        try {
            const response = await fetch(`api/enrollment.php?sport_id=${SPORT_ID}`);
            const data = await response.json();
            
            if (data.success) {
                membersGrid.innerHTML = '';
                
                if (data.members.length === 0) {
                    membersGrid.innerHTML = `
                        <div style="text-align: center; width: 100%; padding: 2rem;">
                            <p style="color: #999; margin-bottom: 1rem;">No members enrolled yet.</p>
                            <p style="color: #ff3333;">Be the first to join this sport!</p>
                        </div>
                    `;
                } else {
                    data.members.forEach((member, index) => {
                        const initials = member.full_name
                            .split(' ')
                            .map(n => n[0])
                            .join('')
                            .toUpperCase()
                            .slice(0, 2);
                        
                        const animationDelay = index * 0.1;
                        
                        membersGrid.innerHTML += `
                            <div class="member-card" style="animation-delay: ${animationDelay}s">
                                <div class="member-avatar" style="background-color: ${getAvatarColor(initials)}">
                                    ${initials}
                                </div>
                                <div class="member-info">
                                    <h4>${escapeHtml(member.full_name)}</h4>
                                    <p>${escapeHtml(member.department)}</p>
                                    <p>${member.semester}th Semester</p>
                                </div>
                            </div>
                        `;
                    });
                }
                
                btn.innerHTML = '<span class="btn-icon">👥</span> Hide Members';
                membersVisible = true;
            } else {
                throw new Error(data.message || 'Failed to load members');
            }
        } catch (error) {
            membersGrid.innerHTML = `
                <div style="text-align: center; width: 100%; padding: 2rem;">
                    <p style="color: #f56565;">Error loading members. Please try again.</p>
                </div>
            `;
            showAlert('Error loading members', 'error');
        }
    } else {
        membersSection.style.display = 'none';
        btn.innerHTML = '<span class="btn-icon">👥</span> View Members';
        membersVisible = false;
    }
}

// Generate consistent avatar colors
function getAvatarColor(initials) {
    const colors = [
        '#e53e3e', '#dd6b20', '#d69e2e', '#38a169',
        '#319795', '#3182ce', '#5a67d8', '#805ad5',
        '#d53f8c', '#ed64a6'
    ];
    
    let hash = 0;
    for (let i = 0; i < initials.length; i++) {
        hash = initials.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Show alert message
function showAlert(message, type = 'info') {
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        font-weight: 500;
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
        max-width: 300px;
    `;
    
    switch (type) {
        case 'success':
            alert.style.backgroundColor = '#48bb78';
            break;
        case 'error':
            alert.style.backgroundColor = '#f56565';
            break;
        default:
            alert.style.backgroundColor = '#4299e1';
    }
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => alert.remove(), 300);
    }, 5000);
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .member-card {
        animation: fadeInUp 0.5s ease-out forwards;
        opacity: 0;
    }
`;
document.head.appendChild(style);