<?php
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>AtleticX Setup</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .success { color: green; }
        .error { color: red; }
        pre { background: #f4f4f4; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>AtleticX Database Setup</h1>
    
    <?php
    try {
        echo "<h3>Creating Database Tables...</h3>";
        
        // Users table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS users (
                user_id INT PRIMARY KEY AUTO_INCREMENT,
                full_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                phone VARCHAR(15) NOT NULL,
                age INT DEFAULT NULL,
                department VARCHAR(50) NOT NULL,
                semester INT NOT NULL,
                profile_photo VARCHAR(255) DEFAULT 'default-avatar.jpg',
                banner_photo VARCHAR(255) DEFAULT 'default-banner.jpg',
                bio TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                last_login TIMESTAMP NULL DEFAULT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                INDEX idx_email (email)
            )
        ");
        echo "<p class='success'>✓ Users table created</p>";
        
        // Sports table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS sports (
                sport_id INT PRIMARY KEY AUTO_INCREMENT,
                sport_name VARCHAR(50) NOT NULL,
                sport_type VARCHAR(50) NOT NULL,
                max_capacity INT NOT NULL,
                current_members INT DEFAULT 0,
                description TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        echo "<p class='success'>✓ Sports table created</p>";
        
        // Enrollments table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS enrollments (
                enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT NOT NULL,
                sport_id INT NOT NULL,
                enrolled_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status ENUM('active', 'inactive') DEFAULT 'active',
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (sport_id) REFERENCES sports(sport_id) ON DELETE CASCADE,
                UNIQUE KEY unique_enrollment (user_id, sport_id)
            )
        ");
        echo "<p class='success'>✓ Enrollments table created</p>";
        
        // Activity log table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS activity_log (
                activity_id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT NOT NULL,
                activity_type VARCHAR(50) NOT NULL,
                activity_description TEXT,
                sport_id INT DEFAULT NULL,
                ip_address VARCHAR(45) DEFAULT NULL,
                user_agent TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY (sport_id) REFERENCES sports(sport_id) ON DELETE SET NULL,
                INDEX idx_user_activity (user_id, created_at)
            )
        ");
        echo "<p class='success'>✓ Activity log table created</p>";
        
        // Insert sports data
        echo "<h3>Inserting Sports Data...</h3>";
        
        $sports = [
            ['Football', 'Team Sport', 40, 'Join our Football team and showcase your skills.'],
            ['Cricket', 'Team Sport', 35, 'Be part of our Cricket team and enjoy the game.'],
            ['Basketball', 'Team Sport', 30, 'Join our Basketball team and shoot some hoops.'],
            ['Volleyball', 'Team Sport', 24, 'Spike your way to victory with our Volleyball team.'],
            ['Badminton', 'Individual/Doubles', 40, 'Master the shuttlecock with our Badminton club.']
        ];
        
        $stmt = $pdo->prepare("INSERT IGNORE INTO sports (sport_name, sport_type, max_capacity, description) VALUES (?, ?, ?, ?)");
        
        foreach ($sports as $sport) {
            $stmt->execute($sport);
        }
        echo "<p class='success'>✓ Sports data inserted</p>";
        
        // Create directories
        echo "<h3>Creating Directories...</h3>";
        
        $dirs = [
            'uploads/profiles',
            'uploads/banners'
        ];
        
        foreach ($dirs as $dir) {
            if (!file_exists($dir)) {
                if (mkdir($dir, 0755, true)) {
                    echo "<p class='success'>✓ Created directory: $dir</p>";
                } else {
                                        echo "<p class='error'>✗ Failed to create directory: $dir</p>";
                }
            } else {
                echo "<p class='success'>✓ Directory exists: $dir</p>";
            }
        }
        
        // Create default images
        if (!file_exists('uploads/profiles/default-avatar.jpg')) {
            $img = imagecreate(150, 150);
            $bg = imagecolorallocate($img, 45, 45, 45);
            $text = imagecolorallocate($img, 255, 255, 255);
            imagestring($img, 5, 55, 70, 'USER', $text);
            imagejpeg($img, 'uploads/profiles/default-avatar.jpg');
            imagedestroy($img);
            echo "<p class='success'>✓ Created default avatar</p>";
        }
        
        if (!file_exists('uploads/banners/default-banner.jpg')) {
            $img = imagecreate(800, 200);
            $bg = imagecolorallocate($img, 255, 51, 51);
            imagefill($img, 0, 0, $bg);
            imagejpeg($img, 'uploads/banners/default-banner.jpg');
            imagedestroy($img);
            echo "<p class='success'>✓ Created default banner</p>";
        }
        
        echo "<h2 style='color: green;'>Setup Complete!</h2>";
        echo "<p><a href='index.php' style='font-size: 18px;'>Go to Login Page →</a></p>";
        
    } catch (Exception $e) {
        echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
    }
    ?>
    
    <hr>
    <h3>Important Notes:</h3>
    <ul>
        <li>Make sure to update <code>config/database.php</code> with your MySQL credentials</li>
        <li>Ensure Apache has write permissions to the <code>uploads</code> directory</li>
        <li>Delete this setup.php file after successful setup for security</li>
    </ul>
</body>
</html>