<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = sanitizeInput($_POST['full_name'] ?? '');
$age = intval($_POST['age'] ?? 0);
$email = sanitizeInput($_POST['email'] ?? '');
$phone = sanitizeInput($_POST['phone'] ?? '');
$department = sanitizeInput($_POST['department'] ?? '');
$semester = intval($_POST['semester'] ?? 0);
$bio = sanitizeInput($_POST['bio'] ?? '');

if (empty($full_name) || empty($email) || empty($phone) || empty($department)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit();
}

if (!validateEmail($email)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit();
}

if (!validatePhone($phone)) {
    echo json_encode(['success' => false, 'message' => 'Invalid phone number']);
    exit();
}

try {
    $checkStmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
    $checkStmt->execute([$email, $user_id]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already in use']);
        exit();
    }
    
    $photoFilename = null;
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === 0) {
        $uploadResult = uploadImage($_FILES['profile_photo'], 'profile');
        if ($uploadResult['success']) {
            $photoFilename = $uploadResult['filename'];
        }
    }
    
    if ($photoFilename) {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET full_name = ?, age = ?, email = ?, phone = ?, department = ?, 
                semester = ?, bio = ?, profile_photo = ?
            WHERE user_id = ?
        ");
        $stmt->execute([$full_name, $age, $email, $phone, $department, $semester, $bio, $photoFilename, $user_id]);
    } else {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET full_name = ?, age = ?, email = ?, phone = ?, department = ?, 
                semester = ?, bio = ?
            WHERE user_id = ?
        ");
        $stmt->execute([$full_name, $age, $email, $phone, $department, $semester, $bio, $user_id]);
    }
    
        $_SESSION['user_name'] = $full_name;
    
    logActivity($pdo, $user_id, 'profile_update', 'Profile information updated');
    
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Update failed. Please try again.']);
}
?>