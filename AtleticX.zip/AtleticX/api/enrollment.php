<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'enroll') {
    $user_id = $_SESSION['user_id'];
    $sport_id = intval($_POST['sport_id'] ?? 0);
    
    if ($sport_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid sport']);
        exit();
    }
    
    try {
        $checkStmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? AND sport_id = ?");
        $checkStmt->execute([$user_id, $sport_id]);
        
        if ($checkStmt->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'You are already enrolled in this sport']);
            exit();
        }
        
        $sportStmt = $pdo->prepare("SELECT sport_name, current_members, max_capacity FROM sports WHERE sport_id = ?");
        $sportStmt->execute([$sport_id]);
        $sport = $sportStmt->fetch();
        
        if ($sport['current_members'] >= $sport['max_capacity']) {
            echo json_encode(['success' => false, 'message' => 'This sport is at full capacity']);
            exit();
        }
        
        $enrollStmt = $pdo->prepare("INSERT INTO enrollments (user_id, sport_id) VALUES (?, ?)");
        $enrollStmt->execute([$user_id, $sport_id]);
        
        $updateStmt = $pdo->prepare("UPDATE sports SET current_members = current_members + 1 WHERE sport_id = ?");
        $updateStmt->execute([$sport_id]);
        
        logActivity($pdo, $user_id, 'enroll', "Enrolled in {$sport['sport_name']}", $sport_id);
        
        echo json_encode(['success' => true, 'message' => 'Successfully enrolled!']);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Enrollment failed. Please try again.']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['sport_id'])) {
    $sport_id = intval($_GET['sport_id']);
    
    try {
        $stmt = $pdo->prepare("
            SELECT u.full_name, u.department, u.semester, u.phone 
            FROM users u 
            JOIN enrollments e ON u.user_id = e.user_id 
            WHERE e.sport_id = ? AND e.status = 'active'
            ORDER BY e.enrolled_date DESC
        ");
        $stmt->execute([$sport_id]);
        $members = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'members' => $members]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching members']);
    }
}
?>