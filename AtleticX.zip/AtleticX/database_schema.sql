-- Create database
CREATE DATABASE IF NOT EXISTS atleticx CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE atleticx;

-- Users table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    age INT DEFAULT NULL,
    department VARCHAR(50) NOT NULL,
    semester INT NOT NULL,
    profile_photo VARCHAR(255) DEFAULT 'default-avatar.jpg',
    banner_photo VARCHAR(255) DEFAULT 'default-banner.jpg',
    bio TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sports table (simplified)
CREATE TABLE sports (
    sport_id INT PRIMARY KEY AUTO_INCREMENT,
    sport_name VARCHAR(50) NOT NULL,
    sport_type VARCHAR(50) NOT NULL,
    max_capacity INT NOT NULL,
    current_members INT DEFAULT 0,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Enrollments table (simplified - no position)
CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    sport_id INT NOT NULL,
    enrolled_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (sport_id) REFERENCES sports(sport_id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (user_id, sport_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Activity log table
CREATE TABLE activity_log (
    activity_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    activity_description TEXT,
    sport_id INT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (sport_id) REFERENCES sports(sport_id) ON DELETE SET NULL,
    INDEX idx_user_activity (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sports data
INSERT INTO sports (sport_name, sport_type, max_capacity, description) VALUES
('Football', 'Team Sport', 40, 'Join our Football team and showcase your skills.'),
('Cricket', 'Team Sport', 35, 'Be part of our Cricket team and enjoy the game.'),
('Basketball', 'Team Sport', 30, 'Join our Basketball team and shoot some hoops.'),
('Volleyball', 'Team Sport', 24, 'Spike your way to victory with our Volleyball team.'),
('Badminton', 'Individual/Doubles', 40, 'Master the shuttlecock with our Badminton club.');