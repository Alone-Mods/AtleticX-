<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AtleticX - College Sports Management</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="container">
        <div class="abstract-bg"></div>
        <header>
            <h1 class="logo">AtleticX</h1>
            <p class="tagline">Your College Sports Hub</p>
        </header>
        
        <main class="auth-container">
            <div class="auth-box">
                <div class="auth-tabs">
                    <button class="tab-btn active" onclick="showLogin()">Login</button>
                    <button class="tab-btn" onclick="showRegister()">Register</button>
                </div>
                
                <form id="loginForm" class="auth-form">
                    <h2>Welcome Back!</h2>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" class="btn-primary">Login</button>
                    <a href="#" class="forgot-link">Forgot Password?</a>
                </form>
                
                <form id="registerForm" class="auth-form" style="display:none;">
                    <h2>Join AtleticX</h2>
                    <input type="text" name="name" placeholder="Full Name" required>
                    <select name="department" class="form-select" required>
                        <option value="">Select Department</option>
                        <option value="Computer Science">Computer Science</option>
                        <option value="Cyber Security">Cyber Security</option>
                        <option value="Artificial Intelligence">Artificial Intelligence</option>
                        <option value="ECE">ECE</option>
                        <option value="EEE">EEE</option>
                        <option value="Polymer">Polymer</option>
                    </select>
                    <select name="semester" class="form-select" required>
                        <option value="">Select Semester</option>
                        <?php for($i = 1; $i <= 8; $i++): ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?>th Semester</option>
                        <?php endfor; ?>
                    </select>
                    <div class="phone-input">
                        <span class="phone-prefix">+91</span>
                        <input type="tel" name="phone" placeholder="Phone Number" pattern="[0-9]{10}" maxlength="10" required>
                    </div>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                    <button type="submit" class="btn-primary">Register</button>
                </form>
            </div>
        </main>
    </div>
    
    <script src="assets/js/main.js"></script>
    <script>
        function showLogin() {
            document.getElementById('loginForm').style.display = 'block';
            document.getElementById('registerForm').style.display = 'none';
            document.querySelectorAll('.tab-btn')[0].classList.add('active');
            document.querySelectorAll('.tab-btn')[1].classList.remove('active');
        }
        
        function showRegister() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('registerForm').style.display = 'block';
            document.querySelectorAll('.tab-btn')[0].classList.remove('active');
            document.querySelectorAll('.tab-btn')[1].classList.add('active');
        }
    </script>
</body>
</html>