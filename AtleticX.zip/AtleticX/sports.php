<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

$stmt = $pdo->query("SELECT * FROM sports WHERE is_active = TRUE");
$sports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php" class="active">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="sports-page">
        <h2>Available Sports</h2>
        
        <div class="sports-grid">
            <?php foreach($sports as $sport): ?>
                <?php 
                    $sportPage = strtolower($sport['sport_name']) . '.php';
                    $sportIcon = '';
                    switch($sport['sport_name']) {
                        case 'Football': $sportIcon = '⚽'; break;
                        case 'Cricket': $sportIcon = '🏏'; break;
                        case 'Basketball': $sportIcon = '🏀'; break;
                        case 'Volleyball': $sportIcon = '🏐'; break;
                        case 'Badminton': $sportIcon = '🏸'; break;                    }
                ?>
                <a href="<?php echo $sportPage; ?>" class="sport-card-link">
                    <div class="sport-card">
                        <div class="sport-header <?php echo strtolower($sport['sport_name']); ?>">
                            <span class="sport-icon"><?php echo $sportIcon; ?></span>
                        </div>
                        <div class="sport-content">
                            <h3><?php echo htmlspecialchars($sport['sport_name']); ?></h3>
                            <p class="member-count"><?php echo $sport['current_members']; ?> Members</p>
                            <button class="btn-explore">View Details →</button>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>