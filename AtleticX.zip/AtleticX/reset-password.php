<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="container">
        <div class="abstract-bg"></div>
        <header>
            <h1 class="logo">AtleticX</h1>
            <p class="tagline">Reset Your Password</p>
        </header>
        
        <main class="auth-container">
            <div class="reset-password-box">
                <form class="reset-form" id="resetPasswordForm">
                    <h2>Create New Password</h2>
                    <p class="reset-description">Please enter your current password and choose a new password for your account.</p>
                    
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" placeholder="Enter current password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" placeholder="Enter new password" required>
                        <small>Password must be at least 8 characters long</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm new password" required>
                    </div>
                    
                    <button type="submit" class="btn-primary">Update Password</button>
                    
                    <div class="form-links">
                        <a href="profile.php" class="back-link">← Back to Profile</a>
                        <a href="dashboard.php" class="back-link">Go to Dashboard</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
    
    <script>
        document.getElementById('resetPasswordForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            
            if (formData.get('new_password') !== formData.get('confirm_password')) {
                alert('New passwords do not match!');
                return;
            }
            
            if (formData.get('new_password').length < 8) {
                alert('Password must be at least 8 characters long!');
                return;
            }
            
            try {
                const response = await fetch('api/password-reset.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Password updated successfully!');
                    window.location.href = 'profile.php';
                } else {
                    alert(data.message || 'Error updating password');
                }
            } catch (error) {
                alert('An error occurred. Please try again.');
            }
        });
    </script>
</body>
</html>