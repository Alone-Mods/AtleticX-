<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

// Get all sports with current member count
$stmt = $pdo->query("SELECT * FROM sports WHERE is_active = TRUE");
$sports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php" class="active">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="sports-page">
        <h2>Available Sports</h2>
        
        <div class="sports-grid">
            <?php foreach($sports as $sport): ?>
                <?php 
                    $sportPage = strtolower($sport['sport_name']) . '.php';
                    $sportIcon = '';
                    switch($sport['sport_name']) {
                        case 'Football': $sportIcon = '⚽'; break;
                        case 'Cricket': $sportIcon = '🏏'; break;
                        case 'Basketball': $sportIcon = '🏀'; break;
                        case 'Volleyball': $sportIcon = '🏐'; break;
                        case 'Badminton': $sportIcon = '🏸'; break;
                    }
                ?>
                <a href="<?php echo $sportPage; ?>" class="sport-card-link">
                    <div class="sport-card">
                        <div class="sport-header <?php echo strtolower($sport['sport_name']); ?>">
                            <span class="sport-icon"><?php echo $sportIcon; ?></span>
                        </div>
                        <div class="sport-content">
                            <h3><?php echo htmlspecialchars($sport['sport_name']); ?></h3>
                            <p class="sport-type"><?php echo htmlspecialchars($sport['sport_type']); ?></p>
                            <div class="sport-info">
                                <p><strong>Schedule:</strong> <?php echo htmlspecialchars($sport['schedule']); ?></p>
                                <p><strong>Location:</strong> <?php echo htmlspecialchars($sport['location']); ?></p>
                                <p class="member-count"><strong>Members:</strong> <?php echo $sport['current_members']; ?> athletes</p>
                            </div>
                            <button class="btn-explore">Explore →</button>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>