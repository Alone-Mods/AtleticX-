// Global variable to track members visibility
let membersVisible = false;

// Show enrollment modal
function showEnrollmentModal() {
    const modal = document.getElementById('enrollmentModal');
    if (modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden'; // Prevent scrolling
    }
}

// Close enrollment modal
function closeEnrollmentModal() {
    const modal = document.getElementById('enrollmentModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = ''; // Restore scrolling
    }
}

// Handle enrollment form submission
document.getElementById('enrollmentForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    formData.append('action', 'enroll');
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enrolling...';
    
    try {
        const response = await fetch('api/enrollment.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showAlert(data.message, 'error');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Confirm Registration';
        }
    } catch (error) {
        showAlert('An error occurred. Please try again.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Confirm Registration';
    }
});

// Load and display team members
async function loadMembers() {
    const membersSection = document.getElementById('membersSection');
    const btn = document.querySelector('.btn-view-members');
    const membersGrid = document.getElementById('membersGrid');
    
    if (!membersVisible) {
        // Show loading state
        membersGrid.innerHTML = '<p style="text-align: center; width: 100%;">Loading members...</p>';
        membersSection.style.display = 'block';
        
        try {
            const response = await fetch(`api/enrollment.php?sport_id=${SPORT_ID}`);
            const data = await response.json();
            
            if (data.success) {
                membersGrid.innerHTML = '';
                
                if (data.members.length === 0) {
                    membersGrid.innerHTML = `
                        <div style="text-align: center; width: 100%; padding: 2rem;">
                            <p style="color: #999; margin-bottom: 1rem;">No members enrolled yet.</p>
                            <p style="color: #ff3333;">Be the first to join this sport!</p>
                        </div>
                    `;
                } else {
                    data.members.forEach((member, index) => {
                        const initials = member.full_name
                            .split(' ')
                            .map(n => n[0])
                            .join('')
                            .toUpperCase()
                            .slice(0, 2);
                        
                        // Add animation delay for staggered appearance
                        const animationDelay = index * 0.1;
                        
                        membersGrid.innerHTML += `
                            <div class="member-card" style="animation-delay: ${animationDelay}s">
                                <div class="member-avatar" style="background-color: ${getAvatarColor(initials)}">
                                    ${initials}
                                </div>
                                <div class="member-info">
                                    <h4>${escapeHtml(member.full_name)}</h4>
                                    <p><strong>Department:</strong> ${escapeHtml(member.department)}</p>
                                    <p><strong>Semester:</strong> ${member.semester}th</p>
                                    <p><strong>Position:</strong> ${escapeHtml(member.position)}</p>
                                    <p><strong>Contact:</strong> +91-${escapeHtml(member.phone)}</p>
                                </div>
                            </div>
                        `;
                    });
                }
                
                btn.innerHTML = '<span class="btn-icon">👥</span> Hide Team Members';
                membersVisible = true;
            } else {
                throw new Error(data.message || 'Failed to load members');
            }
        } catch (error) {
            membersGrid.innerHTML = `
                <div style="text-align: center; width: 100%; padding: 2rem;">
                    <p style="color: #f56565;">Error loading members. Please try again.</p>
                </div>
            `;
            showAlert('Error loading members', 'error');
        }
    } else {
        // Hide members section
        membersSection.style.display = 'none';
        btn.innerHTML = '<span class="btn-icon">👥</span> View Team Members';
        membersVisible = false;
    }
}

// Generate consistent avatar colors based on initials
function getAvatarColor(initials) {
    const colors = [
        '#e53e3e', '#dd6b20', '#d69e2e', '#38a169', 
        '#319795', '#3182ce', '#5a67d8', '#805ad5', 
        '#d53f8c', '#ed64a6'
    ];
    
    let hash = 0;
    for (let i = 0; i < initials.length; i++) {
        hash = initials.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Show alert message (reuse from main.js if loaded, otherwise define here)
if (typeof showAlert === 'undefined') {
    function showAlert(message, type = 'info') {
        const existingAlert = document.querySelector('.alert');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 5px;
            color: white;
            font-weight: 500;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            max-width: 300px;
        `;
        
        switch(type) {
            case 'success':
                alert.style.backgroundColor = '#48bb78';
                break;
            case 'error':
                alert.style.backgroundColor = '#f56565';
                break;
            default:
                alert.style.backgroundColor = '#4299e1';
        }
        
        document.body.appendChild(alert);
        
        setTimeout(() => {
                        alert.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => alert.remove(), 300);
            }, 5000);
            }
            }
            
            // Close modal when clicking outside
            window.onclick = function(event) {
              const modal = document.getElementById('enrollmentModal');
              if (event.target == modal) {
                closeEnrollmentModal();
              }
            }
            
            // Close modal with Escape key
            document.addEventListener('keydown', (e) => {
              if (e.key === 'Escape') {
                closeEnrollmentModal();
              }
            });
            
            // Add member card animation styles
            document.addEventListener('DOMContentLoaded', () => {
              const style = document.createElement('style');
              style.textContent = `
        .member-card {
            animation: fadeInUp 0.5s ease-out forwards;
            opacity: 0;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .members-section {
            animation: fadeIn 0.3s ease-out;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        
        /* Modal animations */
        #enrollmentModal {
            animation: fadeIn 0.3s ease-out;
        }
        
        .modal-content {
            animation: slideDown 0.3s ease-out;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        /* Button hover effects */
        .btn-register:not(:disabled):hover,
        .btn-view-members:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 51, 51, 0.3);
        }
        
        .btn-register:disabled {
            cursor: not-allowed;
            opacity: 0.7;
        }
        
        /* Loading animation */
        @keyframes pulse {
            0% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
            100% {
                opacity: 1;
            }
        }
        
        .loading {
            animation: pulse 1.5s ease-in-out infinite;
        }
    `;
              document.head.appendChild(style);
            });
            
            // Smooth scroll to members section when opened
            function scrollToMembers() {
              const membersSection = document.getElementById('membersSection');
              if (membersSection && membersVisible) {
                setTimeout(() => {
                  membersSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                  });
                }, 100);
              }
            }
            
            // Add scroll functionality to loadMembers
            const originalLoadMembers = loadMembers;
            loadMembers = async function() {
              await originalLoadMembers();
              if (membersVisible) {
                scrollToMembers();
              }
            };
            
            // Handle network errors gracefully
            window.addEventListener('offline', () => {
              showAlert('You are offline. Please check your internet connection.', 'error');
            });
            
            window.addEventListener('online', () => {
              showAlert('You are back online!', 'success');
            });
            
            // Prevent form resubmission on page refresh
            if (window.history.replaceState) {
              window.history.replaceState(null, null, window.location.href);
            }
            
            // Add touch support for mobile devices
            let touchStartX = 0;
            let touchEndX = 0;
            
            document.addEventListener('touchstart', (e) => {
              touchStartX = e.changedTouches[0].screenX;
            });
            
            document.addEventListener('touchend', (e) => {
              touchEndX = e.changedTouches[0].screenX;
              handleSwipe();
            });
            
            function handleSwipe() {
              const modal = document.getElementById('enrollmentModal');
              if (modal && modal.style.display === 'block') {
                if (touchEndX < touchStartX - 50) {
                  // Swiped left - could close modal on mobile
                }
              }
            }
            
            // Utility function to format phone numbers
            function formatPhoneNumber(phone) {
              if (phone.length === 10) {
                return phone.replace(/(\d{5})(\d{5})/, '$1-$2');
              }
              return phone;
            }
            
            // Check if user is already enrolled (for dynamic UI updates)
            async function checkEnrollmentStatus() {
              try {
                const response = await fetch(`api/check-enrollment.php?sport_id=${SPORT_ID}`);
                const data = await response.json();
                
                if (data.enrolled) {
                  const enrollBtn = document.querySelector('.btn-register');
                  if (enrollBtn) {
                    enrollBtn.textContent = 'Already Enrolled';
                    enrollBtn.disabled = true;
                    enrollBtn.classList.add('btn-enrolled');
                    enrollBtn.classList.remove('btn-register');
                  }
                }
              } catch (error) {
                console.error('Error checking enrollment status:', error);
              }
            }
            
            // Initialize on page load
            document.addEventListener('DOMContentLoaded', () => {
              // Check enrollment status if SPORT_ID is defined
              if (typeof SPORT_ID !== 'undefined') {
                checkEnrollmentStatus();
              }
              
              // Add ripple effect to buttons
              const buttons = document.querySelectorAll('.btn-register, .btn-view-members, .btn-primary');
              buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                  const ripple = document.createElement('span');
                  ripple.classList.add('ripple');
                  this.appendChild(ripple);
                  
                  const x = e.clientX - e.target.offsetLeft;
                  const y = e.clientY - e.target.offsetTop;
                  
                  ripple.style.left = `${x}px`;
                  ripple.style.top = `${y}px`;
                  
                  setTimeout(() => {
                    ripple.remove();
                  }, 600);
                });
              });
            });
            
            // Add ripple effect styles
            const rippleStyle = document.createElement('style');
            rippleStyle.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.5);
        transform: scale(0);
        animation: ripple-animation 0.6s ease-out;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    button {
        position: relative;
        overflow: hidden;
    }
`;
            document.head.appendChild(rippleStyle);
            
            // Export functions for use in other scripts if needed
            window.sportFunctions = {
              showEnrollmentModal,
              closeEnrollmentModal,
              loadMembers,
              checkEnrollmentStatus,
              showAlert,
              formatPhoneNumber
            };