<?php
// Fix the require_once paths
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
requireLogin();

$user = getUserData($pdo, $_SESSION['user_id']);

// Handle case where user data might not be found
if (!$user) {
    session_destroy();
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="dashboard">
        <div class="welcome-section">
            <h2>Welcome back, <span class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></span>!</h2>
            <p>Manage your sports activities and connect with fellow athletes</p>
        </div>
        
        <div class="quick-actions">
            <h3>What would you like to do today?</h3>
            <div class="action-cards">
                <a href="sports.php" class="action-card">
                    <div class="card-icon">🏃</div>
                    <h4>Browse Sports</h4>
                    <p>Explore and enroll in available sports</p>
                </a>
                <a href="profile.php" class="action-card">
                    <div class="card-icon">👤</div>
                    <h4>My Profile</h4>
                    <p>View and update your information</p>
                </a>
            </div>
        </div>
    </main>
</body>
</html>