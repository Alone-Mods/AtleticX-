<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

$sport_id = 1;
$user_id = $_SESSION['user_id'];

// Check enrollment status
$enrollCheck = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? AND sport_id = ?");
$enrollCheck->execute([$user_id, $sport_id]);
$isEnrolled = $enrollCheck->rowCount() > 0;

// Get sport details
$sportStmt = $pdo->prepare("SELECT * FROM sports WHERE sport_id = ?");
$sportStmt->execute([$sport_id]);
$sport = $sportStmt->fetch();

// Get positions
$positionsStmt = $pdo->prepare("SELECT * FROM sport_positions WHERE sport_id = ?");
$positionsStmt->execute([$sport_id]);
$positions = $positionsStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="sport-detail-page">
        <div class="sport-hero football-hero">
            <div class="hero-content">
                <span class="sport-icon-large">⚽</span>
                <h1>Football</h1>
                <p>Join our passionate football community</p>
            </div>
        </div>
        
        <div class="sport-detail-container">
            <div class="sport-info-section">
                <h2>About Football at AtleticX</h2>
                <p><?php echo htmlspecialchars($sport['description'] ?? 'Experience the thrill of the beautiful game with our college football team.'); ?></p>
                
                <div class="info-grid">
                    <div class="info-card">
                        <h3>📅 Schedule</h3>
                        <p><?php echo htmlspecialchars($sport['schedule']); ?></p>
                    </div>
                    <div class="info-card">
                        <h3>📍 Location</h3>
                        <p><?php echo htmlspecialchars($sport['location']); ?></p>
                    </div>
                    <div class="info-card">
                        <h3>👨‍🏫 Coach</h3>
                        <p><?php echo htmlspecialchars($sport['coach_name']); ?></p>
                    </div>
                    <div class="info-card">
                        <h3>👥 Team Size</h3>
                        <p><?php echo $sport['current_members']; ?> Active Members<br>Max capacity: <?php echo $sport['max_capacity']; ?></p>
                    </div>
                </div>
                
                <div class="sport-actions-section">
                    <?php if (!$isEnrolled): ?>
                        <button class="btn-register" onclick="showEnrollmentModal()">
                            <span class="btn-icon">✓</span>
                            Register for Football
                        </button>
                    <?php else: ?>
                        <button class="btn-enrolled" disabled>
                            <span class="btn-icon">✓</span>
                            Already Enrolled
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn-view-members" onclick="loadMembers()">
                        <span class="btn-icon">👥</span>
                        View Team Members
                    </button>
                </div>
            </div>
            
            <div id="membersSection" class="members-section" style="display: none;">
                <h2>Team Members</h2>
                <div class="members-grid" id="membersGrid">
                    <!-- Members loaded dynamically -->
                </div>
            </div>
        </div>
    </main>
    
    <!-- Enrollment Modal -->
    <div id="enrollmentModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeEnrollmentModal()">&times;</span>
            <h2>Register for Football</h2>
            <form id="enrollmentForm">
                <div class="form-group">
                    <label>Select Your Position</label>
                    <select name="position" required>
                        <?php foreach ($positions as $position): ?>
                            <option value="<?php echo htmlspecialchars($position['position_name']); ?>">
                                <?php echo htmlspecialchars($position['position_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <input type="hidden" name="sport_id" value="<?php echo $sport_id; ?>">
                <button type="submit" class="btn-primary">Confirm Registration</button>
            </form>
        </div>
    </div>
    
    <script src="assets/js/sport-functions.js"></script>
</body>
</html>