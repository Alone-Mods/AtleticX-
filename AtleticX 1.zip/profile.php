<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

$user = getUserData($pdo, $_SESSION['user_id']);

// Get enrolled sports
$enrolledStmt = $pdo->prepare("
    SELECT s.sport_name, s.sport_id, e.position 
    FROM enrollments e 
    JOIN sports s ON e.sport_id = s.sport_id 
    WHERE e.user_id = ? AND e.status = 'active'
");
$enrolledStmt->execute([$_SESSION['user_id']]);
$enrolledSports = $enrolledStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php" class="active">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="profile-page">
        <div class="profile-container">
            <div class="profile-banner">
                <button class="banner-edit-btn">📷 Change Banner</button>
            </div>
            
            <div class="profile-photo-section">
                <div class="profile-photo">
                    <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile Photo">
                    <button class="photo-edit-btn">📷</button>
                </div>
            </div>
            
            <div class="profile-info">
                <h2 class="profile-name"><?php echo htmlspecialchars($user['full_name']); ?></h2>
                
                <div class="info-section">
                    <h3>Personal Information</h3>
                    <div class="info-row">
                        <div class="info-item">
                            <label>Full Name</label>
                            <p><?php echo htmlspecialchars($user['full_name']); ?></p>
                        </div>
                        <div class="info-item">
                            <label>Age</label>
                            <p><?php echo htmlspecialchars($user['age'] ?? 'Not specified'); ?> years</p>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-item">
                            <label>Department</label>
                            <p><?php echo htmlspecialchars($user['department']); ?></p>
                        </div>
                        <div class="info-item">
                            <label>Semester</label>
                            <p><?php echo htmlspecialchars($user['semester']); ?>th Semester</p>
                        </div>
                    </div>
                </div>
                
                <div class="info-section">
                    <h3>Contact Information</h3>
                    <div class="info-row">
                        <div class="info-item">
                            <label>Email ID</label>
                            <p><?php echo htmlspecialchars($user['email']); ?></p>
                        </div>
                        <div class="info-item">
                            <label>Phone Number</label>
                            <p>+91-<?php echo htmlspecialchars($user['phone']); ?></p>
                        </div>
                    </div>
                </div>
                
                <?php if (count($enrolledSports) > 0): ?>
                <div class="info-section">
                    <h3>Enrolled Sports</h3>
                    <div class="enrolled-sports-list">
                        <?php foreach ($enrolledSports as $sport): ?>
                            <div class="enrolled-sport-item">
                                <span><?php echo htmlspecialchars($sport['sport_name']); ?></span>
                                <span class="position"><?php echo htmlspecialchars($sport['position']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="profile-actions">
                    <a href="edit-profile.php" class="btn-edit">Edit Profile</a>
                    <a href="reset-password.php" class="btn-password">Reset Password</a>
                </div>
            </div>
        </div>
    </main>
</body>
</html>