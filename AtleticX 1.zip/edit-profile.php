<?php
require_once 'config/database.php';
require_once 'includes/auth.php';
requireLogin();

$user = getUserData($pdo, $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - AtleticX</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h1 class="nav-logo">AtleticX</h1>
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="sports.php">Sports</a></li>
                <li><a href="profile.php" class="active">Profile</a></li>
                <li><a href="api/logout.php" class="logout">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <main class="edit-profile-page">
        <div class="edit-profile-container">
            <div class="edit-header">
                <h2>Edit Profile</h2>
                <p>Update your personal information</p>
            </div>
            
            <form class="edit-profile-form" id="editProfileForm">
                <div class="edit-photo-section">
                    <div class="edit-photo">
                        <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_photo']); ?>" alt="Profile Photo">
                        <div class="photo-overlay">
                            <label for="photo-upload" class="photo-upload-btn">
                                📷 Change Photo
                            </label>
                            <input type="file" id="photo-upload" name="profile_photo" accept="image/*" style="display: none;">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3>Personal Information</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Age</label>
                            <input type="number" name="age" value="<?php echo htmlspecialchars($user['age'] ?? ''); ?>" min="17" max="30">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Department</label>
                            <select name="department" required>
                                <option value="Computer Science" <?php echo $user['department'] == 'Computer Science' ? 'selected' : ''; ?>>Computer Science</option>
                                <option value="Electronics" <?php echo $user['department'] == 'Electronics' ? 'selected' : ''; ?>>Electronics & Communication</option>
                                <option value="Mechanical" <?php echo $user['department'] == 'Mechanical' ? 'selected' : ''; ?>>Mechanical</option>
                                <option value="Civil" <?php echo $user['department'] == 'Civil' ? 'selected' : ''; ?>>Civil</option>
                                <option value="Electrical" <?php echo $user['department'] == 'Electrical' ? 'selected' : ''; ?>>Electrical</option>
                                <option value="IT" <?php echo $user['department'] == 'IT' ? 'selected' : ''; ?>>Information Technology</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Semester</label>
                            <select name="semester" required>
                                <?php for($i = 1; $i <= 8; $i++): ?>
                                                                        <option value="<?php echo $i; ?>" <?php echo $user['semester'] == $i ? 'selected' : ''; ?>>
                                        <?php echo $i; ?>th Semester
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3>Contact Information</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Email ID</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <div class="phone-input-edit">
                                <span class="phone-prefix">+91</span>
                                <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" pattern="[0-9]{10}" maxlength="10" required>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3>Additional Information</h3>
                    <div class="form-group">
                        <label>Bio (Optional)</label>
                        <textarea name="bio" rows="4" placeholder="Tell us about yourself, your sports interests, achievements, etc."><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn-save">Save Changes</button>
                    <a href="profile.php" class="btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </main>
    
    <script>
        document.getElementById('editProfileForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            
            try {
                const response = await fetch('api/profile-update.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Profile updated successfully!');
                    window.location.href = 'profile.php';
                } else {
                    alert(data.message || 'Error updating profile');
                }
            } catch (error) {
                alert('An error occurred. Please try again.');
            }
        });
        
        document.getElementById('photo-upload').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector('.edit-photo img').src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>